library(testthat)
library(airquality)

test_check('airquality')
